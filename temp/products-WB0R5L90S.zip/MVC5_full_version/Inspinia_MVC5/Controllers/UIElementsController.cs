﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Inspinia_MVC5.Controllers
{
    public class UIElementsController : Controller
    {

        public ActionResult Typography()
        {
            return View();
        }

        public ActionResult Icons()
        {
            return View();
        }

        public ActionResult DraggablePanels()
        {
            return View();
        }

        public ActionResult Buttons()
        {
            return View();
        }

        public ActionResult Video()
        {
            return View();
        }

        public ActionResult TablesPanels()
        {
            return View();
        }

        public ActionResult NotificationsTooltips()
        {
            return View();
        }

        public ActionResult BadgesLabelsProgress()
        {
            return View();
        }
	}
}