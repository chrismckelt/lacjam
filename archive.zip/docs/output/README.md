This file is in the `docs/output` directory.

This directory will contain the final artifacts for both narrative and API documentation. 
This folder will be automatically created by the documenation generation process.

**It is strongly recommended that nothing be put into this directory.**

It is **strongly advised** that the **contents of this directory not be committed** to source control 
(with the sole exception being this `README.md` file).

---

NOTE: 

This file is a placeholder, used to preserve directory structure in Git.

This file does not need to be edited.
