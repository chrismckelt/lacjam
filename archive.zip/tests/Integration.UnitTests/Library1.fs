﻿namespace Integration.UnitTests

type Class1() = 
    member this.X = "F#"
