﻿namespace ServiceBus.UnitTests

type Class1() = 
    member this.X = "F#"
