This file is in the `lib` directory.

Any **libraries** on which your project depends and which are **NOT managed via NuGet** should be kept **in this directory**.
This typically includes custom builds of third-party software, private (i.e. to a company) codebases, and native libraries.

---
NOTE: 

This file is a placeholder, used to preserve directory structure in Git.

This file does not need to be edited.
