This file is in the `nuget` directory.

You should use this directory to store any artifacts required to produce a NuGet package for your project.
This typically includes a `.nuspec` file and some `.ps1` scripts, for instance.
Additionally, this example project includes a `.cmd` file suitable for manual deployment of packages to <a href="http://nuget.org" target="_blank">http://nuget.org</a>.

---
NOTE: 

This file is a placeholder, used to preserve directory structure in Git.

This file does not need to be edited.
