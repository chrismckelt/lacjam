﻿namespace Integration

type Class1() = 
    member this.X = "F#"
