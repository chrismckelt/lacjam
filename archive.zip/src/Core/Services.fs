﻿namespace Lacjam.Core
    open System
    open Microsoft.FSharp
    open Microsoft.FSharp.Core
    open Microsoft.FSharp.Collections

    [<AutoOpen>]
    module Services =   ()
