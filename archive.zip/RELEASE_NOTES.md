#### 0.0.0-beta - October 19 2013
* Initial release

#### 0.0.1-beta - October 24 2013
* Changed name from fsharp-project-scaffold to FSharp.ProjectScaffold

#### 0.5.0-beta - October 29 2013
* Improved quality of solution-wide README.md files

#### 0.5.1-beta - November 6 2013
* Improved quality of solution-wide README.md files

### 1.0 - Unreleased
* More awesome stuff comming
