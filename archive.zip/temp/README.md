This file is in the `temp` directory.

This directory is used by the build process as a "scratch", or working, area.

**It is strongly recommended that nothing be put into this directory.**

It is **strongly advised** that the **contents of this directory not be committed** to source control 
(with the sole exception being this `README.md` file).

---
NOTE: 

This file is a placeholder, used to preserve directory structure in Git.

This file does not need to be edited.
